package com.example.modul2_nomer2

data class Football(val imgView: Int, val txtTitle:String, val txtSubTitle:String)